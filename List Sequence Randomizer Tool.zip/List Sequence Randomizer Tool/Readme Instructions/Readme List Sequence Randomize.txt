replace All FILENAME entries in List Sequence Randomizer.bat
to enable randomization of your personal list.

rename to .txt instead of .bat to edit FILENAME entires.

this will allow full listed randomizing, scrambling, of your text list
file!!!!!!!!!!!!!!!!!!!!!

END <3

==========================================================================================================================

p.s.

you may have to go to windows folder options and enable showing of file extensions,

Control Panel > Appearance and Personalization > Folder Options > View > *DISABLE* HIDE EXTENSIONS FOR KNOWN FILE-TYPES.

now rename the .bat to .txt and edit FILENAME entries To your PERSONAL LIST ENTRY!!!

DONE <3